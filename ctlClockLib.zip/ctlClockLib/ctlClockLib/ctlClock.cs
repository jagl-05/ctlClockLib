﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ctlClockLib
{
    public partial class ctlClock : UserControl
    {
        public ctlClock()
        {
            InitializeComponent();
            lblDisplay.Text = DateTime.Now.ToLongTimeString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblDisplay.Text = DateTime.Now.ToLongTimeString();
        }
        public Color ClockBackColor
        {
            get => lblDisplay.BackColor;
            set => lblDisplay.BackColor = value;
        }

        public Color ClockForeColor
        {
            get => lblDisplay.ForeColor;
            set => lblDisplay.ForeColor = value;
        }
    }

}
