﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ctlClockLib
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ctlClock reloj = new ctlClock();
            reloj.Location = new Point(10, 10);
            reloj.Size = new Size(200, 50);     
            this.Controls.Add(reloj);           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
