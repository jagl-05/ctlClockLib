﻿using System;
using System.Drawing;
using System.Windows.Forms;

public class ctlAlarmClock : ctlClock
{
    private Timer blinkTimer;
    private bool isBlinking = false;
    private bool blinkState = false;
    private DateTime alarmTime;

    public ctlAlarmClock()
    {
        blinkTimer = new Timer();
        blinkTimer.Interval = 500; // Medio segundo
        blinkTimer.Tick += BlinkTimer_Tick;

        this.AlarmTime = DateTime.Now.AddMinutes(1); // Alarma por defecto
    }

    public DateTime AlarmTime
    {
        get => alarmTime;
        set => alarmTime = value;
    }

    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);
        this.timer1.Tick += CheckAlarm;
    }

    private void CheckAlarm(object sender, EventArgs e)
    {
        // Si la hora actual coincide con la hora de alarma (solo horas:minutos)
        if (!isBlinking && DateTime.Now.Hour == alarmTime.Hour && DateTime.Now.Minute == alarmTime.Minute)
        {
            StartBlinking();
        }
    }

    private void StartBlinking()
    {
        isBlinking = true;
        blinkTimer.Start();
    }

    private void BlinkTimer_Tick(object sender, EventArgs e)
    {
        // Parpadeo: alternar el color del texto
        if (blinkState)
            this.ForeColor = Color.Red;
        else
            this.ForeColor = Color.Black;

        blinkState = !blinkState;
    }
}
